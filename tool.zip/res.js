const Imap = require('imap');
const {simpleParser} = require('mailparser');

const imap = new Imap({
    user: '_mainaccount@localink.in',
    password: '_r4g0o(Jhh.e',
    host: 'mail.localink.in',
    port: 993,
    tls: true,
    tlsOptions: { rejectUnauthorized: false }
});

function openInbox(cb) {
    imap.openBox('INBOX', false, cb);
}

imap.once('ready', function () {
    openInbox((err, box) => {
        if (err) throw err;

        imap.search(['*'], function (err, results) {
            if (err) throw err;
            if (!results || results.length === 0) {
                console.log('No new replies.');
                imap.end();
                return;
            }

            const fetch = imap.fetch(results, { bodies: '' });
            fetch.on('message', function (msg, seqno) {
                msg.on('body', function (stream, info) {
                    simpleParser(stream, (err, mail) => {
                        if (err) throw err;

                        console.log('From:', mail.from.text);
                        console.log('Subject:', mail.subject);
                        console.log('Body:', mail.text);

                        const match = mail.subject.match(/\[ID: (.+)\]/) || mail.text.match(/\[ID: (.+)\]/);
                        if (match) {
                            const uniqueId = match[1];
                            console.log('Reply matched to original email with ID:', uniqueId);
                        }
                    });
                });
            });

            fetch.once('end', function () {
                console.log('Done fetching replies.');
                imap.end();
            });
        });
    });
});

imap.once('error', function (err) {
    console.error('IMAP Error:', err);
});

imap.once('end', function () {
    console.log('Connection ended.');
});

imap.connect();