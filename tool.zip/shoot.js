
const nodemailer = require('nodemailer');
const xlsx = require('xlsx');
const fs = require('fs');
require('dotenv').config();

const workbook = xlsx.readFile('demo.xlsx');
const sheet_name = workbook.SheetNames[0];
const sheet = workbook.Sheets[sheet_name];

const contacts = xlsx.utils.sheet_to_json(sheet);

console.log(contacts)

const transporter = nodemailer.createTransport({
    host: process.env.EMAIL_HOST,
    port: 587,
    secure: false,
    auth: {
      user: process.env.EMAIL_USER,
      pass: process.env.EMAIL_PASS,
    },
});

const users = [
    "Alice", "Bob", "Charlie", "David", "Eve",
    "Fay", "George", "Hannah", "Ian", "Jack",
    "Kathy", "Liam", "Megan", "Nancy", "Oliver",
    "Penny", "Quinn", "Rachel", "Steve", "Tina",
    "Ursula"
];

const mailOptions = {
    from: 'demofirst@influex.club',
    subject: 'Your Subject Here',
    text: 'Hello, this is a test email.',
    html: '<p>Hello, this is a <strong>test email</strong>.</p>'
};

var index = 0;
async function sendEmails() {
    for (let contact of contacts) {
        index = index + 1;
        try {
            mailOptions.from = `${users[index]}@influex.club`;
            mailOptions.to = contact.Email;
            mailOptions.subject = `Unwind and Rejuvenate – Special Offer Just for You!`;
            mailOptions.html = `<pre>Dear ${contact.Email.split("@")[0]},

We know how busy life can get, which is why we’ve created the perfect getaway just for you! At [Your Spa Name], we offer a relaxing environment to help you refresh your mind and body.

🌟 Special Offer: 20% Off Your Next Spa Treatment! 🌟

Whether you’re looking for a soothing massage, a rejuvenating facial, or a relaxing soak, our expert therapists are here to help you unwind. Treat yourself to some well-deserved pampering!

This Offer Includes:

[Highlight popular services, e.g., Swedish Massage, Deep Tissue Massage, Aromatherapy Facial, etc.]
Complimentary refreshments and a calming ambiance
A personalized experience to meet your needs
Hurry! This offer is valid until ${new Date().toDateString()}. Simply book your appointment today and use the code RELAX20 to receive your 20% discount.

How to Book:

Visit our website or
Call us at  to reserve your spot.
We can’t wait to welcome you to and provide you with the relaxation you deserve!

Warm regards,</pre>`;
            await transporter.sendMail(mailOptions);
            console.log(`Email sent to: ${contact.Email}`);
        } catch (error) {
            console.error(`Error sending email to ${contact.Email}: ${error.message}`);
        }
    }
}

sendEmails();