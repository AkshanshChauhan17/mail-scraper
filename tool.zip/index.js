const https = require('https');
const xlsx = require("xlsx");

const userAgents = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/113.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36",
    "Mozilla/5.0 (X11; Ubuntu; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/111.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36",
];

const referers = [
    "https://www.google.com/"
];

const acceptLanguages = [
    "en-US,en;q=0.9",
    "en-GB,en;q=0.8",
    "fr-FR,fr;q=0.7,en;q=0.6",
    "de-DE,de;q=0.7,en;q=0.5"
];

var topic = "Dentist";
var country = "";
const city_list = [
    "Los Angeles",
    "San Diego",
    "San Jose",
    "San Francisco",
    "Fresno",
    "Sacramento (capital)",
    "Long Beach",
    "Oakland",
    "Bakersfield",
    "Anaheim",
    "Santa Ana",
    "Riverside",
    "Stockton",
    "Chula Vista",
    "Irvine",
    "Fremont",
    "San Bernardino"
];

var mail_type = "gmail.com";

const consolidateDataToExcel = (cityData) => {
    const workbook = xlsx.utils.book_new();

    const consolidatedData = [];

    cityData.forEach(({ city, range, emails }) => {
        emails.forEach(email => {
            consolidatedData.push({ City: city, Range: range, Email: email });
        });
    });

    const consolidatedSheet = xlsx.utils.json_to_sheet(consolidatedData);
    xlsx.utils.book_append_sheet(workbook, consolidatedSheet, 'Consolidated');

    const filePath = `All_Cities_${topic}_email_list.xlsx`;
    xlsx.writeFile(workbook, filePath);

    console.log(`Excel file created successfully at ${filePath}`);
};

const fetchData = (startIndex, city) => {
    return new Promise((resolve, reject) => {
        const userAgent = userAgents[Math.floor(Math.random() * userAgents.length)];
        const referer = referers[Math.floor(Math.random() * referers.length)];
        const acceptLanguage = acceptLanguages[Math.floor(Math.random() * acceptLanguages.length)];

        const options = {
            headers: {
                'User-Agent': userAgent,
                'Accept-Language': acceptLanguage,
                'Referer': referer,
                'Connection': 'keep-alive',
                'DNT': '1',
                'Upgrade-Insecure-Requests': '1',
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
            },
        };

        https.get(
            `https://www.google.com/search?q=%22${topic}%22+%22%40${mail_type}%22+%22${city}%22&rlz=1C1ONGR_enIN1127IN1127&num=100&start=${startIndex}`,
            options,
            (response) => {
                let data = '';

                response.on('data', (chunk) => {
                    data += chunk;
                });

                response.on('end', () => {
                    if (response.statusCode === 200) {
                        const emailRegex = /[a-zA-Z0-9._%+-]+@gmail\.com/g;
                        const emails = data.match(emailRegex) || [];
                        resolve(emails);
                    } else {
                        console.error(`Request failed with status: ${response.statusCode}`);
                        reject(new Error(`Non-200 status code: ${response.statusCode}`));
                    }
                });
            }
        ).on('error', (err) => {
            console.error(`Error: ${err.message}`);
            reject(err);
        });
    });
};

const throttleRequests = async() => {
    const cityData = [];

    for (const city of city_list) {
        const uniqueEmails = new Set();

        for (let i = 0; i < 300; i += 100) {
            try {
                console.log(`Fetching results for city: ${city}, range: ${i}-${i + 100}`);
                const emails = await fetchData(i, city);
                emails.forEach(email => uniqueEmails.add(email));
                await new Promise(resolve => setTimeout(resolve, Math.random() * 3727 + 7312));
            } catch (error) {
                console.error(`Error fetching data for city ${city}, range ${i}: ${error.message}`);
            }
        }

        cityData.push({
            city,
            range: "0-300",
            emails: [...uniqueEmails],
        });
    }

    consolidateDataToExcel(cityData);
};

throttleRequests();